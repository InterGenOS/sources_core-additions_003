void _gnutls_register_accel_crypto(void);
