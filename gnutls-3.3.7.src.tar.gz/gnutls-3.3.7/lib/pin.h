#ifndef PIN_H
#define PIN_H

extern gnutls_pin_callback_t _gnutls_pin_func;
extern void *_gnutls_pin_data;

#endif				/* PIN_H */
