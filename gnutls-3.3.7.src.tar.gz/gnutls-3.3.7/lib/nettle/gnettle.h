#define PRIME_CHECK_PARAM 8
#define TOMPZ(x) ((__mpz_struct*)(x))
#define SIZEOF_MPZT sizeof(__mpz_struct)
